
(() => {
  const LS_TASKS = "adhd-simplified/tasks";
  const LS_ORDER = "adhd-simplified/todayOrder";
  const LS_FOCUS = "adhd-simplified/focus";
  const LS_SETTINGS = "adhd-simplified/settings";

  const todayStr = () => new Date().toISOString().slice(0,10);

  const byId = (id) => document.getElementById(id);

  function load(key, def) {
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : def; } catch { return def; }
  }
  function save(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  }

  // --- Settings ---
  const settings = Object.assign({
    emailRemindersEnabled: false,
    emailAddress: "",
    emailIntervalMin: 120,
    soundEnabled: true,
  }, load(LS_SETTINGS, {}));

  function beep() {
    if (!settings.soundEnabled) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator(); const g = ctx.createGain();
      o.type = "sine"; o.frequency.value = 880; o.connect(g); g.connect(ctx.destination);
      g.gain.setValueAtTime(0.0001, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.02);
      o.start(); setTimeout(() => { g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.15); o.stop(ctx.currentTime + 0.2); }, 160);
    } catch {}
  }

  // --- Data ---
  let tasks = load(LS_TASKS, []);
  let orderMap = load(LS_ORDER, {});
  let focusMapAll = load(LS_FOCUS, {});
  const today = todayStr();
  let chat = [{ role: "bot", text: "Paste your journal or write freely. I’ll extract tasks and add them to Today (no commas needed)." }];

  // --- Helpers ---
  function extractTasksFromJournal(raw) {
    const chunks = raw.split(/\n+/).flatMap(line => line.split(/(?<=[.!?])\s+/)).map(s=>s.trim()).filter(Boolean);
    const verbHints = /(finish|clean|email|mail|call|text|message|pay|submit|send|review|write|draft|plan|schedule|book|buy|order|exercise|workout|study|read|water|laundry|vacuum|dishes|cook|prep|organize|backup|back\s?up|update|fix|debug|deploy|push|commit|test|meet|ping|follow\s?up)\b/i;
    const out = [];
    for (const c of chunks) {
      if (/^\d{4}-\d{2}-\d{2}|^note:|^journal:|^mood:|^thoughts:/i.test(c)) continue;
      if (verbHints.test(c) || /^[-•\[]/.test(c)) {
        const cleaned = c.replace(/^[-•\[\]\s]+/, "").replace(/^today\s*:\s*/i, "").trim();
        if (cleaned.length >= 3) out.push(cleaned);
      }
    }
    return out.length ? out : (raw.trim() ? [raw.trim()] : []);
  }

  function uuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
      const r = Math.random()*16|0, v = c === "x" ? r : (r&0x3|0x8); return v.toString(16);
    });
  }

  function addTask(title) {
    const t = {
      id: uuid(),
      title: title.trim(),
      steps: [
        { id: uuid(), label: "Open context", done: false },
        { id: uuid(), label: "Do first tiny step", done: false },
        { id: uuid(), label: "Mark done", done: false },
      ],
      priority: 3,
      createdAt: todayStr(),
      scheduledFor: todayStr(),
      done: false,
    };
    tasks.push(t);
    const ord = orderMap[today] || [];
    ord.push(t.id);
    orderMap[today] = ord;
    persist();
    render();
  }

  function deleteTask(id) {
    tasks = tasks.filter(t => t.id !== id);
    orderMap[today] = (orderMap[today] || []).filter(x => x !== id);
    const day = Object.assign({}, focusMapAll[today] || {});
    delete day[id];
    focusMapAll[today] = day;
    if (focusedTaskId === id) focusedTaskId = undefined;
    persist();
    render();
  }

  function updatePriority(id, p) {
    tasks = tasks.map(t => t.id === id ? Object.assign({}, t, { priority: p }) : t);
    persist();
    render();
  }

  function up(id) {
    const ord = orderMap[today] || [];
    const i = ord.indexOf(id);
    if (i > 0) { [ord[i-1], ord[i]] = [ord[i], ord[i-1]]; orderMap[today] = ord; persist(); render(); }
  }
  function down(id) {
    const ord = orderMap[today] || [];
    const i = ord.indexOf(id);
    if (i >= 0 && i < ord.length-1) { [ord[i+1], ord[i]] = [ord[i], ord[i+1]]; orderMap[today] = ord; persist(); render(); }
  }

  function persist() {
    save(LS_TASKS, tasks);
    save(LS_ORDER, orderMap);
    save(LS_FOCUS, focusMapAll);
    save(LS_SETTINGS, settings);
  }

  // --- Focus tracking (Pomodoro) ---
  let focusedTaskId = undefined;
  let running = false;
  let seconds = 25*60;
  let remain = seconds;
  let tickHandle = null;

  function setFocusLabel() {
    byId("focusLabel").textContent = focusedTaskId
      ? "Focus: " + (tasks.find(t => t.id === focusedTaskId)?.title || "")
      : "Pick a task (Focus) to load.";
  }

  function setTimerDisplay() {
    const m = String(Math.floor(remain/60)).padStart(2,"0");
    const s = String(remain%60).padStart(2,"0");
    byId("tMin").textContent = m;
    byId("tSec").textContent = s;
  }

  function startTimer() {
    if (!focusedTaskId) return;
    if (running) return;
    running = True = true;
    const start = Date.now();
    tickHandle = setInterval(() => {
      const left = Math.max(0, seconds - Math.floor((Date.now() - start)/1000));
      remain = left;
      // credit 1s to focused task
      const fm = focusMapAll[today] || {};
      fm[focusedTaskId] = (fm[focusedTaskId] || 0) + 1;
      focusMapAll[today] = fm;
      setTimerDisplay();
      if (left <= 0) {
        clearInterval(tickHandle); tickHandle = null; running = false;
        beep();
      }
      if (left % 5 === 0) { // throttle persistence a bit
        persist();
        renderTop3Badges();
      }
    }, 1000);
  }

  function pauseTimer() {
    if (!running) return;
    running = false;
    clearInterval(tickHandle); tickHandle = null;
    // recalc seconds for resume from remain
    seconds = remain;
    persist();
    renderTop3Badges();
  }

  function resetTimer() {
    running = false;
    clearInterval(tickHandle); tickHandle = null;
    remain = seconds;
    setTimerDisplay();
  }

  function clearTimer() {
    running = false; clearInterval(tickHandle); tickHandle = null;
    focusedTaskId = undefined; setFocusLabel();
  }

  // timer presets
  document.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-min]");
    if (btn) {
      const m = parseInt(btn.getAttribute("data-min"), 10);
      seconds = m*60; remain = seconds; setTimerDisplay();
    }
  });

  byId("btnStart").onclick = startTimer;
  byId("btnPause").onclick = pauseTimer;
  byId("btnReset").onclick = resetTimer;
  byId("btnClear").onclick = clearTimer;

  // --- Chat ---
  function addBubble(role, text) {
    const wrap = byId("chatLog");
    const div = document.createElement("div");
    div.style.display = "flex";
    div.style.justifyContent = role === "user" ? "flex-end" : "flex-start";
    const b = document.createElement("div");
    b.className = "bubble " + (role === "user" ? "user" : "bot");
    b.textContent = text;
    div.appendChild(b);
    wrap.appendChild(div);
    wrap.scrollTop = wrap.scrollHeight;
  }

  function sendChat() {
    const input = byId("chatInput");
    const text = input.value.trim();
    if (!text) return;
    addBubble("user", text);
    const items = extractTasksFromJournal(text);
    items.forEach(addTask);
    addBubble("bot", `Added ${items.length} task${items.length>1?'s':''} to Today. Top 3 = first three.`);
    input.value = "";
    beep();
  }

  byId("btnSend").onclick = sendChat;
  byId("chatInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendChat(); }
  });

  // --- Email reminders (when app is open) ---
  let emailTimer = null;
  function scheduleEmailReminder() {
    if (emailTimer) { clearInterval(emailTimer); emailTimer = null; }
    if (!settings.emailRemindersEnabled || !settings.emailAddress || settings.emailIntervalMin <= 0) return;
    emailTimer = setInterval(() => {
      // Build mailto
      const ord = (orderMap[today] || []).slice(0,3);
      const focusMap = focusMapAll[today] || {};
      const lines = ord.map((id, idx) => {
        const t = tasks.find(x=>x.id===id); if (!t) return ""; const mins = Math.floor((focusMap[id]||0)/60);
        return `${idx+1}. ${t.title} — ${mins} min focused`;
      }).filter(Boolean);
      const subject = encodeURIComponent("Gentle check-in: today's Top 3 focus");
      const body = encodeURIComponent(`Your Top 3 for ${today}:\n\n${lines.join("\n")}\n\n(Open BrainHack to reorder/add.)`);
      const href = `mailto:${settings.emailAddress}?subject=${subject}&body=${body}`;
      const link = document.getElementById("mailtoLink");
      link.href = href;
      document.getElementById("mailtoWrap").style.display = "block";
      addBubble("bot", "📧 Email reminder ready — tap the mail link below to send.");
    }, settings.emailIntervalMin * 60 * 1000);
  }

  // Settings modal (very minimal prompt-based UI)
  document.getElementById("btnSettings").onclick = () => {
    const emailEnabled = confirm("Enable email reminders? OK = Yes, Cancel = No");
    settings.emailRemindersEnabled = emailEnabled;
    if (emailEnabled) {
      const addr = prompt("Send reminders to which email address?", settings.emailAddress || "");
      settings.emailAddress = addr || "";
      const mins = parseInt(prompt("Every how many minutes? (min 5)", String(settings.emailIntervalMin || 120)) || "120", 10);
      settings.emailIntervalMin = Math.max(5, mins || 120);
      persist();
      scheduleEmailReminder();
      alert("Email reminders set. A mailto draft will be prepared periodically while the app is open.");
    } else {
      persist();
      scheduleEmailReminder();
    }
  };

  // --- Rendering ---
  function ensureOrder() {
    const todayIds = tasks.filter(t=>t.scheduledFor===today).map(t=>t.id);
    const ord = orderMap[today] || [];
    const fixed = ord.filter(id => todayIds.includes(id));
    const missing = todayIds.filter(id => !fixed.includes(id));
    orderMap[today] = [...fixed, ...missing];
    save(LS_ORDER, orderMap);
  }

  function renderTop3Badges() {
    const ord = (orderMap[today] || []);
    const top3 = new Set(ord.slice(0,3));
    const focusMap = focusMapAll[today] || {};
    const min15 = 15*60;
    document.querySelectorAll(".task").forEach(el => {
      const id = el.getAttribute("data-id");
      el.classList.remove("red","green");
      if (top3.has(id)) {
        const sec = focusMap[id] || 0;
        el.classList.add(sec < min15 ? "red" : "green");
        const meter = el.querySelector(".top3meter");
        if (meter) meter.textContent = `${Math.floor(sec/60)}m / 15m`;
      } else {
        const meter = el.querySelector(".top3meter");
        if (meter) meter.textContent = "";
      }
    });
  }

  function render() {
    ensureOrder();
    const list = byId("list");
    list.innerHTML = "";
    const ord = orderMap[today] || [];
    const top3 = new Set(ord.slice(0,3));
    const focusMap = focusMapAll[today] || {};
    const min15 = 15*60;

    for (const id of ord) {
      const t = tasks.find(x=>x.id===id); if (!t) continue;
      const total = t.steps.length;
      const done = t.steps.filter(s=>s.done).length;
      const pct = Math.round((done/total)*100);
      const sec = focusMap[id] || 0;
      const isTop = top3.has(id);

      const card = document.createElement("div");
      card.className = "task card";
      if (isTop) card.classList.add(sec<min15 ? "red":"green");
      card.setAttribute("data-id", id);

      const head = document.createElement("div");
      head.className = "row";
      const left = document.createElement("div");
      left.className = "col";
      const title = document.createElement("h4");
      title.textContent = t.title;
      const meta = document.createElement("div");
      meta.className = "meta";
      if (isTop) {
        const top = document.createElement("span");
        top.className = "badge"; top.textContent = "Top";
        meta.appendChild(top);
        const meter = document.createElement("span");
        meter.className = "top3meter"; meter.textContent = `${Math.floor(sec/60)}m / 15m`;
        meta.appendChild(meter);
      }
      const priWrap = document.createElement("div");
      priWrap.className = "group";
      const priLabel = document.createElement("span");
      priLabel.className = "muted"; priLabel.textContent = "Priority";
      const sel = document.createElement("select");
      [1,2,3,4,5].forEach(v => {
        const opt = document.createElement("option"); opt.value = v; opt.textContent = v;
        if (t.priority === v) opt.selected = true;
        sel.appendChild(opt);
      });
      sel.onchange = () => updatePriority(id, parseInt(sel.value,10));
      priWrap.appendChild(priLabel); priWrap.appendChild(sel);

      left.appendChild(title);
      left.appendChild(meta);
      left.appendChild(priWrap);

      const right = document.createElement("div");
      right.className = "group";
      const btnFocus = document.createElement("button");
      btnFocus.className = "btn btn-sm"; btnFocus.textContent = "Focus";
      btnFocus.onclick = () => { focusedTaskId = id; setFocusLabel(); };
      const btnUp = document.createElement("button");
      btnUp.className = "btn btn-sm"; btnUp.textContent = "↑"; btnUp.title = "Move up";
      btnUp.onclick = () => up(id);
      const btnDown = document.createElement("button");
      btnDown.className = "btn btn-sm"; btnDown.textContent = "↓"; btnDown.title = "Move down";
      btnDown.onclick = () => down(id);
      const btnDel = document.createElement("button");
      btnDel.className = "btn btn-sm btn-ghost"; btnDel.textContent = "Delete";
      btnDel.onclick = () => deleteTask(id);

      right.appendChild(btnFocus);
      right.appendChild(btnUp);
      right.appendChild(btnDown);
      right.appendChild(btnDel);

      head.appendChild(left);
      head.appendChild(right);

      const prog = document.createElement("div");
      prog.className = "progress";
      const bar = document.createElement("div");
      bar.style.width = pct + "%";
      prog.appendChild(bar);

      const sub = document.createElement("div");
      sub.className = "muted";
      sub.style.fontSize = "11px";
      sub.textContent = `${done}/${total} steps • ${pct}%`;

      card.appendChild(head);
      card.appendChild(prog);
      card.appendChild(sub);

      list.appendChild(card);
    }
    renderTop3Badges();
  }

  // Initial render + first bot message
  addBubble("bot", chat[0].text);
  render();
  setFocusLabel();
  setTimerDisplay();
  scheduleEmailReminder();

  // Self-tests (open by adding #debug to the URL)
  if (location.hash.includes("debug")) {
    const tests = [];
    function assert(name, cond, details) { tests.push({name, ok: !!cond, details}); }
    // extraction tests
    const sample = "Woke up late. Need to email Anna about the report. Also vacuum the car. Might cook.\nJournal: feeling okay.";
    const items = extractTasksFromJournal(sample);
    assert("extracts at least 2 actions", items.length >= 2, "got " + items.length);
    assert("ignores Journal: header", !items.some(s=>/Journal:/i.test(s)));
    // threshold
    assert("15-min threshold numeric", 15*60 === 900);
    const ul = document.getElementById("tests");
    tests.forEach(t => {
      const li = document.createElement("li");
      li.textContent = (t.ok ? "PASS" : "FAIL") + " — " + t.name + (t.details ? " (" + t.details + ")" : "");
      li.style.color = t.ok ? "#22c55e" : "#ef4444";
      ul.appendChild(li);
    });
    document.getElementById("debug").style.display = "block";
  }

  // --- Service worker registration ---
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("./sw.js").catch(()=>{});
    });
  }
})();
